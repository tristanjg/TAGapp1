package com.example.tristan.tagapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class callmee extends AppCompatActivity {

    private int PERMISSION_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_callmee);

        Button buttonRequest = findViewById(R.id.salesButton);
        buttonRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(callmee.this, Manifest.permission.CALL_PHONE)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Permission is granted
                    //Toast.makeText(CallUs.this, "You have already granted permission.", Toast.LENGTH_SHORT).show();
                    OnSalesButtonClick(v);
                } else {
                    requestPhonePermission();
                }
            }
        });

        Button buttonRequest1 = findViewById(R.id.serviceButton);
        buttonRequest1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(callmee.this, Manifest.permission.CALL_PHONE)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Permission is granted
                    //Toast.makeText(CallUs.this, "You have already granted permission.", Toast.LENGTH_SHORT).show();
                    OnServiceButtonClick(v);
                } else {
                    requestPhonePermission();
                }
            }
        });

        Button buttonRequest2 = findViewById(R.id.partsButton);
        buttonRequest2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(callmee.this, Manifest.permission.CALL_PHONE)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Permission is granted
                    //Toast.makeText(CallUs.this, "You have already granted permission.", Toast.LENGTH_SHORT).show();
                    OnPartsButtonClick(v);
                } else {
                    requestPhonePermission();
                }
            }
        });

        Button buttonRequest3 = findViewById(R.id.rsaButton);
        buttonRequest3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(callmee.this, Manifest.permission.CALL_PHONE)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Permission is granted
                    //Toast.makeText(CallUs.this, "You have already granted permission.", Toast.LENGTH_SHORT).show();
                    OnRSAButtonClick(v);
                } else {
                    requestPhonePermission();
                }
            }
        });

    }
    private void requestPhonePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CALL_PHONE)){
            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("This permission is need in order to call from the app.")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(callmee.this,
                                    new String[] {Manifest.permission.CALL_PHONE},
                                    PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else{
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == PERMISSION_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,"Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void OnSalesButtonClick(View v) {
        //Create New Intent to Allow User To Call A Given Number
        Intent salesCallIntent = new Intent(Intent.ACTION_CALL);
        salesCallIntent.setData(Uri.parse("tel:8157442760"));
        //Start the new Activity
        startActivity(salesCallIntent);
    }

    public void OnServiceButtonClick(View v) {
        //Create New Intent to Allow User To Call A Given Number
        Intent serviceCallIntent = new Intent(Intent.ACTION_CALL);
        serviceCallIntent.setData(Uri.parse("tel:8157442760"));
        //Start the new Activity
        startActivity(serviceCallIntent);
    }
    public void OnPartsButtonClick(View v) {
        //Create New Intent to Allow User To Call A Given Number
        Intent partsCallIntent = new Intent(Intent.ACTION_CALL);
        partsCallIntent.setData(Uri.parse("tel:8157442760"));
        //Start the new Activity
        startActivity(partsCallIntent);
    }
    public void OnRSAButtonClick(View v) {
        //Create New Intent to Allow User To Call A Given Number
        Intent rsaCallIntent = new Intent(Intent.ACTION_CALL);
        rsaCallIntent.setData(Uri.parse("tel:8004444195"));
        //Start the new Activity
        startActivity(rsaCallIntent);
    }
}
