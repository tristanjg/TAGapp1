package com.example.tristan.tagapp;

import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Button buttontwo;
    private Button buttonthree;
    private Button buttonfour;
    private Button buttonfive;
    private Button buttonsix;
    ConstraintLayout myLayout;
    AnimationDrawable animationDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myLayout = (ConstraintLayout) findViewById(R.id.myLayout);

        animationDrawable = (AnimationDrawable) myLayout.getBackground();
        animationDrawable.setEnterFadeDuration(4500);
        animationDrawable.setExitFadeDuration(4500);
        animationDrawable.start();

        button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCallUs();
            }
        });

        buttontwo = (Button) findViewById(R.id.button3);
        buttontwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openservice();
            }
        });

        buttonthree = (Button) findViewById(R.id.button6);
        buttonthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openspecials();
            }
        });

        buttonfour = (Button) findViewById(R.id.button7);
        buttonfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openinventory();
            }
        });

        buttonfive = (Button) findViewById(R.id.button5);
        buttonfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opentradein();
            }
        });

        buttonsix = (Button) findViewById(R.id.button4);
        buttonsix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openrefernearn();
            }
        });
    }

    public void openCallUs() {
        Intent intent = new Intent(this, callmee.class);
        startActivity(intent);
    }

    public void openservice() {
        //Create New Intent :  Sending to Service Website
        Intent serviceIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.romeovilletoyota.com/service-specials-new/"));
        //Start the new Activity
        startActivity(serviceIntent);
    }

    public void openspecials() {
        //Create New Intent :  Sending to Specials Website
        Intent specialsIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.romeovilletoyota.com/search/special/tp/"));
        //Start the new Activity
        startActivity(specialsIntent);
    }

    public void openinventory() {
        Intent intent = new Intent(this, inventory.class);
        startActivity(intent);
    }

    public void openrefernearn() {
        //Create New Intent :  Sending to Refer and Earn Website
        Intent referIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.referthomastoyotajoliet.com/"));
        //Start the new Activity
        startActivity(referIntent);
    }

    public void opentradein() {
        //Create New Intent :  Sending to TradeIn Website
        Intent tradeinIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.romeovilletoyota.com/appraise-trade/"));
        //Start the new Activity
        startActivity(tradeinIntent);
    }
}
